# подключаем бд (а также настраиваем)
import os
APP_NAME = "Чудо Обувь"
DB_SETTINGS = {
    "host": os.getenv("CHUDO_DB_HOST", "localhost"),
    "port": int(os.getenv("CHUDO_DB_PORT", "5432")),
    "dbname": os.getenv("CHUDO_DB_NAME", "chudo_obuv"),
    "user": os.getenv("CHUDO_DB_USER", "postgres"),
    "password": os.getenv("CHUDO_DB_PASSWORD", "postgres"),
}

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
RESOURCES_DIR = os.path.join(BASE_DIR, "resources")
IMAGES_DIR = os.path.join(RESOURCES_DIR, "images")
PLACEHOLDER_PATH = os.path.join(RESOURCES_DIR, "picture.png")
LOGO_PATH = os.path.join(RESOURCES_DIR, "logo.png")
ICON_PATH = os.path.join(RESOURCES_DIR, "icon.ico")


FONT_FAMILY = "Calibri"
COLOR_MAIN_BG = "#FFFFFF"
COLOR_EXTRA_BG = "#D2F6E7"
COLOR_ACCENT = "#70B2AF"  
COLOR_LOW_STOCK = "#ff8080"

LOW_STOCK_LIMIT = 3        
DISCOUNT_PERCENT = 25      
